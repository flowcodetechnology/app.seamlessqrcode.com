<?php

/* Load all the related plugin files */
require_once \Altum\Plugin::get('ultimate-blocks')->path . 'UltimateBlocks.php';
